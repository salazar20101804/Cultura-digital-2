
  # Climate Change Data Analysis

  This is a code bundle for Climate Change Data Analysis. The original project is available at https://www.figma.com/design/HboA3IqzhzykTJkrE5Jeo6/Climate-Change-Data-Analysis.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  