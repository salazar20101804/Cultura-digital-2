import { useEffect, useRef, useState } from 'react';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showContent, setShowContent] = useState(false);
  const [showPrimerParcial, setShowPrimerParcial] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const fontSize = 14;
    const columns = canvas.width / fontSize;
    const drops: number[] = [];

    for (let i = 0; i < columns; i++) {
      drops[i] = Math.random() * -100;
    }

    function draw() {
      if (!ctx || !canvas) return;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0f0';
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }

    const interval = setInterval(draw, 33);

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      clearInterval(interval);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative size-full overflow-auto bg-black">
      <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full" />

      <div className="relative z-10 min-h-full p-8">
        <h1 className="text-5xl font-bold text-center mb-12 text-[#0f0] animate-pulse drop-shadow-[0_0_10px_#0f0]">
          CULTURA DIGITAL
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto mb-8">
          <div className="panel bg-black/70 backdrop-blur-sm p-6 rounded-lg border-2 border-cyan-400 shadow-lg hover:scale-105 hover:shadow-cyan-400/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-cyan-400 mb-2">🌐 Internet</h2>
            <p className="text-gray-300">Conecta personas de todo el mundo.</p>
          </div>

          <div className="panel bg-black/70 backdrop-blur-sm p-6 rounded-lg border-2 border-purple-400 shadow-lg hover:scale-105 hover:shadow-purple-400/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-purple-400 mb-2">🤖 IA</h2>
            <p className="text-gray-300">La inteligencia artificial transforma la sociedad.</p>
          </div>

          <div className="panel bg-black/70 backdrop-blur-sm p-6 rounded-lg border-2 border-green-400 shadow-lg hover:scale-105 hover:shadow-green-400/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-green-400 mb-2">🔒 Seguridad</h2>
            <p className="text-gray-300">Protección de datos y privacidad digital.</p>
          </div>

          <div className="panel bg-black/70 backdrop-blur-sm p-6 rounded-lg border-2 border-sky-400 shadow-lg hover:scale-105 hover:shadow-sky-400/50 transition-all duration-300">
            <h2 className="text-2xl font-bold text-sky-400 mb-2">☁️ Nube</h2>
            <p className="text-gray-300">Almacenamiento y acceso desde cualquier lugar.</p>
          </div>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-black/70 backdrop-blur-sm p-4 rounded-lg border-2 border-[#00bfff] shadow-lg">
              <h2 className="text-xl font-bold text-[#00bfff] mb-3">
                📊 Hoja de Cálculo sobre el Cambio Climático
              </h2>

              <button
                onClick={() => setShowContent(!showContent)}
                className="w-full bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-500 transition-colors"
              >
                {showContent ? 'Ocultar Reflexión ▲' : 'Ver Reflexión ▼'}
              </button>
            </div>

            <div className="bg-black/70 backdrop-blur-sm p-4 rounded-lg border-2 border-cyan-400 shadow-lg">
              <h2 className="text-xl font-bold text-cyan-400 mb-3">
                📄 Google Docs sobre el Cambio Climático
              </h2>

              <button
                onClick={() => setShowPrimerParcial(!showPrimerParcial)}
                className="w-full bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-500 transition-colors"
              >
                {showPrimerParcial ? 'Ocultar Reflexión ▲' : 'Ver Reflexión ▼'}
              </button>
            </div>
          </div>

          {showContent && (
            <div className="bg-white rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)] mb-8">
              <h3 className="text-2xl font-semibold text-[#00bfff] mb-4">
                Lo que entendí de la actividad
              </h3>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Al realizar esta actividad en Google Sheets aprendí a organizar información mediante una hoja de cálculo. Primero creé una tabla donde registré datos relacionados con el cambio climático, incluyendo los años, la temperatura promedio global, la cantidad de dióxido de carbono (CO₂) presente en la atmósfera y el nivel del mar.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Mientras observaba los datos pude identificar que la temperatura promedio global ha aumentado con el paso de los años. También comprendí que el CO₂ es uno de los principales gases responsables del efecto invernadero, ya que contribuye al calentamiento global y provoca cambios en el clima de nuestro planeta.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Otro aspecto importante que observé fue el incremento del nivel del mar. Esto ocurre debido al derretimiento de los glaciares y al aumento de la temperatura global. Estos cambios representan un riesgo para muchas regiones del mundo y demuestran la importancia de cuidar el medio ambiente.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Para elaborar esta hoja de cálculo utilicé filas y columnas para organizar la información de manera clara y ordenada. Ingresé cada dato en su respectiva categoría para facilitar la comparación entre los diferentes años. Gracias a esta actividad aprendí que las hojas de cálculo son herramientas muy útiles para analizar información y representar datos de forma sencilla.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Además, mejoré mis habilidades en el uso de Google Sheets, aprendiendo a crear tablas, organizar información y presentar datos de una manera más profesional. Esta experiencia me permitió comprender mejor la relación entre la contaminación, el aumento de la temperatura y los cambios que están ocurriendo en el planeta.
              </p>

              <p className="text-justify leading-[1.8] mb-6 text-gray-800">
                En conclusión, esta actividad me ayudó a entender que el cambio climático es un problema que afecta a todo el mundo y que es necesario tomar medidas para reducir la contaminación y proteger los recursos naturales. También aprendí la importancia de utilizar herramientas digitales para analizar información y comunicar resultados de forma clara y organizada.
              </p>

              <div className="border-t-2 border-gray-200 pt-6">
                <h4 className="text-lg font-semibold text-gray-700 mb-4">📂 Ver archivos relacionados:</h4>
                <div className="flex flex-col gap-3">
                  <a
                    href="https://docs.google.com/spreadsheets/d/1i_WAK523lht1olKVFJtyR0EkZhSQjfoYWJr01fTSqbQ/edit?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#00bfff] text-white font-bold py-3 px-6 rounded-lg hover:bg-cyan-500 transition-colors text-center"
                  >
                    📊 Abrir Hoja de Cálculo →
                  </a>
                  <a
                    href="https://docs.google.com/document/d/1nNEwwgztAv_hBQ1vKQHtmepzXQN3tDjOHK2xbhpq-b0/edit?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-cyan-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-cyan-500 transition-colors text-center"
                  >
                    📄 Abrir Documento Google Docs →
                  </a>
                </div>
              </div>
            </div>
          )}

          {showPrimerParcial && (
            <div className="bg-white rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)] mb-8">
              <h3 className="text-2xl font-semibold text-cyan-600 mb-4">
                Lo que aprendí sobre Google Docs
              </h3>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Durante esta actividad del primer parcial trabajé con Google Docs y aprendí sobre la importancia de las herramientas de procesamiento de texto en la nube. Google Docs es una aplicación que permite crear, editar y compartir documentos de texto de manera colaborativa desde cualquier dispositivo con conexión a Internet.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Una de las ventajas más importantes de Google Docs es que los documentos se guardan automáticamente en la nube, lo que significa que no hay riesgo de perder el trabajo realizado. Además, permite trabajar en equipo de forma simultánea, ya que varias personas pueden editar el mismo documento al mismo tiempo y ver los cambios en tiempo real.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Aprendí a utilizar diferentes herramientas de formato como los estilos de texto, la alineación, los encabezados y las listas. También descubrí cómo insertar imágenes, tablas y enlaces, lo que hace que los documentos sean más completos y profesionales. La posibilidad de compartir documentos mediante un enlace facilita mucho el trabajo colaborativo.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                Comprendí que Google Docs forma parte del ecosistema de Google Workspace, que incluye otras herramientas como Google Sheets, Google Slides y Google Drive. Esta integración permite organizar mejor el trabajo y acceder fácilmente a todos los archivos desde una misma plataforma.
              </p>

              <p className="text-justify leading-[1.8] mb-4 text-gray-800">
                La cultura digital implica saber usar estas herramientas tecnológicas de manera responsable y eficiente. Google Docs me ayudó a desarrollar competencias digitales importantes como la organización de información, la comunicación efectiva a través de documentos escritos y el trabajo colaborativo en línea.
              </p>

              <p className="text-justify leading-[1.8] mb-6 text-gray-800">
                En conclusión, esta actividad me permitió comprender mejor cómo las herramientas digitales están transformando la manera en que estudiamos, trabajamos y nos comunicamos. Google Docs es un ejemplo claro de cómo la tecnología en la nube facilita el acceso a la información y mejora la productividad en el entorno educativo y laboral.
              </p>

              <div className="border-t-2 border-gray-200 pt-6">
                <h4 className="text-lg font-semibold text-gray-700 mb-4">📂 Ver archivos relacionados:</h4>
                <div className="flex flex-col gap-3">
                  <a
                    href="https://docs.google.com/spreadsheets/d/1i_WAK523lht1olKVFJtyR0EkZhSQjfoYWJr01fTSqbQ/edit?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#00bfff] text-white font-bold py-3 px-6 rounded-lg hover:bg-cyan-500 transition-colors text-center"
                  >
                    📊 Abrir Hoja de Cálculo →
                  </a>
                  <a
                    href="https://docs.google.com/document/d/1nNEwwgztAv_hBQ1vKQHtmepzXQN3tDjOHK2xbhpq-b0/edit?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-cyan-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-cyan-500 transition-colors text-center"
                  >
                    📄 Abrir Documento Google Docs →
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}