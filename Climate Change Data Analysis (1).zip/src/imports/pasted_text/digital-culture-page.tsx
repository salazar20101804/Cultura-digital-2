import { useEffect, useRef } from 'react';
import LanguageIcon from '@mui/icons-material/Language';
import PsychologyIcon from '@mui/icons-material/Psychology';
import SecurityIcon from '@mui/icons-material/Security';
import CloudIcon from '@mui/icons-material/Cloud';
import DescriptionIcon from '@mui/icons-material/Description';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const characters = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const fontSize = 14;
    const columns = canvas.width / fontSize;
    const drops: number[] = Array(Math.floor(columns)).fill(1);

    function draw() {
      if (!ctx || !canvas) return;

      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0F0';
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = characters.charAt(Math.floor(Math.random() * characters.length));
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }

    const interval = setInterval(draw, 33);

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      clearInterval(interval);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="min-h-screen bg-black relative overflow-auto">
      <canvas
        ref={canvasRef}
        className="fixed top-0 left-0 w-full h-full pointer-events-none z-0"
      />

      <div className="relative z-10 py-12 px-4">
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-[#0F0] animate-pulse drop-shadow-[0_0_10px_#0F0] px-4">
          Página web de cultura digital de lo que hemos aprendido todo el parcial
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-8">
          <div className="bg-black/70 backdrop-blur-sm border-2 border-[#0F0] rounded-lg p-6 hover:scale-105 hover:shadow-[0_0_20px_#0F0] transition-all duration-300 cursor-pointer">
            <LanguageIcon className="text-[#0F0] text-5xl mb-3 mx-auto block" />
            <h2 className="text-2xl font-bold text-[#0F0] text-center mb-2">🌐 Internet</h2>
            <p className="text-[#0F0]/80 text-center">Conecta personas de todo el mundo.</p>
          </div>

          <div className="bg-black/70 backdrop-blur-sm border-2 border-[#0F0] rounded-lg p-6 hover:scale-105 hover:shadow-[0_0_20px_#0F0] transition-all duration-300 cursor-pointer">
            <PsychologyIcon className="text-[#0F0] text-5xl mb-3 mx-auto block" />
            <h2 className="text-2xl font-bold text-[#0F0] text-center mb-2">🤖 IA</h2>
            <p className="text-[#0F0]/80 text-center">La inteligencia artificial transforma la sociedad.</p>
          </div>

          <div className="bg-black/70 backdrop-blur-sm border-2 border-[#0F0] rounded-lg p-6 hover:scale-105 hover:shadow-[0_0_20px_#0F0] transition-all duration-300 cursor-pointer">
            <SecurityIcon className="text-[#0F0] text-5xl mb-3 mx-auto block" />
            <h2 className="text-2xl font-bold text-[#0F0] text-center mb-2">🔒 Seguridad</h2>
            <p className="text-[#0F0]/80 text-center">Protección de datos y privacidad digital.</p>
          </div>

          <div className="bg-black/70 backdrop-blur-sm border-2 border-[#0F0] rounded-lg p-6 hover:scale-105 hover:shadow-[0_0_20px_#0F0] transition-all duration-300 cursor-pointer">
            <CloudIcon className="text-[#0F0] text-5xl mb-3 mx-auto block" />
            <h2 className="text-2xl font-bold text-[#0F0] text-center mb-2">☁️ Nube</h2>
            <p className="text-[#0F0]/80 text-center">Almacenamiento y acceso desde cualquier lugar.</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto mb-8">
          <section className="bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)]">
            <div className="flex items-center justify-center gap-3 mb-6">
              <DescriptionIcon className="text-[#00bfff] text-4xl" />
              <h2 className="text-3xl font-bold text-center text-[#00bfff]">📄 Primer Parcial</h2>
            </div>

            <h3 className="text-2xl font-semibold text-[#00bfff] mb-4">Lo que entendí de la actividad</h3>

            <p className="text-justify leading-relaxed mb-4 text-gray-800">
              Al realizar esta actividad aprendí más sobre el cambio climático y también sobre cómo utilizar Google Docs para crear documentos de manera organizada. Primero leí la información sobre el tema y seleccioné los datos más importantes para comprender mejor de qué trataba. Después abrí Google Docs y comencé a redactar el documento desde cero.
            </p>

            <p className="text-justify leading-relaxed mb-4 text-gray-800">
              Para realizar el trabajo escribí un título relacionado con el tema y luego fui agregando la información en diferentes párrafos para que fuera más fácil de leer. También revisé la ortografía, corregí algunos errores y acomodé el texto para que se viera ordenado y presentable. Aprendí que Google Docs es una herramienta muy útil porque permite guardar los trabajos automáticamente, realizar cambios en cualquier momento y compartir los documentos de manera sencilla.
            </p>

            <p className="text-justify leading-relaxed mb-4 text-gray-800">
              Sobre el tema, entendí que el cambio climático es una modificación del clima de la Tierra causada principalmente por actividades humanas como la contaminación, la quema de combustibles fósiles y la deforestación. Estas acciones aumentan los gases de efecto invernadero y provocan que la temperatura global continúe aumentando.
            </p>

            <p className="text-justify leading-relaxed mb-4 text-gray-800">
              También aprendí que el cambio climático tiene consecuencias importantes, como el derretimiento de los glaciares, el aumento del nivel del mar, las sequías, las inundaciones y fenómenos meteorológicos más intensos. Estos cambios afectan tanto a los ecosistemas como a las personas y representan un reto para el futuro de nuestro planeta.
            </p>

            <p className="text-justify leading-relaxed mb-6 text-gray-800">
              Gracias a esta actividad pude comprender mejor la importancia de cuidar el medio ambiente y tomar conciencia sobre nuestras acciones diarias. Además, mejoré mis habilidades en el uso de herramientas digitales como Google Docs, aprendiendo a organizar información, redactar documentos y presentar contenidos de forma clara y ordenada.
            </p>

            <a
              href="https://docs.google.com/document/d/1nNEwwgztAv_hBQ1vKQHtmepzXQN3tDjOHK2xbhpq-b0/edit?usp=sharing"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-[#00bfff] text-white px-6 py-3 rounded-lg hover:bg-[#0099cc] transition-colors duration-300 font-semibold"
            >
              Ver Documento Completo en Google Docs
            </a>
          </section>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          <section className="bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)]">
            <h2 className="text-3xl font-bold text-center text-[#00bfff] mb-6">Importancia</h2>
            <p className="text-justify leading-relaxed text-gray-800">
              La cultura digital permite acceder a información, aprender nuevas
              habilidades, comunicarse con otras personas y participar en la
              sociedad de manera más eficiente.
            </p>
          </section>

          <section className="bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)]">
            <h2 className="text-3xl font-bold text-center text-[#00bfff] mb-6">Beneficios</h2>
            <ul className="space-y-3 text-gray-800">
              <li className="flex items-start">
                <span className="text-[#00bfff] mr-2">✓</span>
                <span>Acceso rápido a la información.</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00bfff] mr-2">✓</span>
                <span>Comunicación instantánea.</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00bfff] mr-2">✓</span>
                <span>Educación en línea.</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00bfff] mr-2">✓</span>
                <span>Trabajo y colaboración a distancia.</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00bfff] mr-2">✓</span>
                <span>Desarrollo de habilidades tecnológicas.</span>
              </li>
            </ul>
          </section>

          <section className="bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-[0_0_15px_rgba(0,0,0,0.2)] mb-12">
            <h2 className="text-3xl font-bold text-center text-[#00bfff] mb-6">Uso Responsable</h2>
            <p className="text-justify leading-relaxed text-gray-800">
              Es importante utilizar internet de forma segura, proteger los
              datos personales, respetar a los demás y verificar la información
              antes de compartirla.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}